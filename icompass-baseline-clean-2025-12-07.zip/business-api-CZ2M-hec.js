import{s as g}from"./index-n_6EX3sY.js";const m=20;async function h(d={}){const{search:s="",status:t,isActive:i,categoryId:a,island:r,page:l=1,pageSize:o=m}=d,c=(l-1)*o,u=c+o-1;let e=g.from("businesses").select(`
      id,
      title,
      description,
      category_id,
      phone,
      email,
      website,
      address,
      island,
      status,
      is_verified,
      is_active,
      searchable,
      slug,
      image_url,
      created_at,
      updated_at,
      categories (
        id,
        title
      )
    `,{count:"exact"}).order("created_at",{ascending:!1}).range(c,u);s.trim()&&(e=e.or(`title.ilike.%${s.trim()}%,description.ilike.%${s.trim()}%`)),t&&t!=="all"&&(e=e.eq("status",t)),i!==void 0&&(e=e.eq("is_active",i)),a&&(e=e.eq("category_id",a)),r&&(e=e.eq("island",r));const{data:f,error:n,count:_}=await e;return n?(console.error("[fetchBusinesses] Error",n),{businesses:[],total:0}):{businesses:f??[],total:_??0}}export{h as f};
